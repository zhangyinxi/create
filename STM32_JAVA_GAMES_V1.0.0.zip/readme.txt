
/********************* (C) COPYRIGHT 2015 STMicroelectronics *******************
  * @file    readme.txt 
  * @author  MCD Tools Team
  * @version V1.0.0
  * @date    09-March-2015
  *****************************************************************************/

STM32F429I-DISCO Java Demonstration - Games In Java

This demonstration is an embedded Java application developed with STM32Java.
The demonstration runs on STM32F429I Discovery board cadenced at 180 MHz and benefits from different components like the gyroscope and Chrom-ART Accelerator� for enhanced graphic content creation (DMA2D).

The package contains the following files:

  � GamesInJava.hex
    The demonstration binary
	
  � GamesInJava-src.zip
    The demonstration java source files
  
  � Getting Started with Games in Java.pdf
    Gives an overview of the demonstration and describes how to run the demonstration
  
  � STM32F429I-DISCO-bsp.zip
    The board support package project containing the Low-Level APIs source files.
  
  � STM32F429I-DISCO-Cube-CM4_ARMCC-1.0.0.jpf
    The Java Platform for STM32F429I-DISCO

/********************* (C) COPYRIGHT 2015 STMicroelectronics ******************/
